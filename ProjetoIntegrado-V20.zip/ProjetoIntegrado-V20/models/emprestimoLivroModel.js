const Database = require('../db/database');
const UsuarioModel = require("../models/usuarioModel");

const conexao = new Database();

class EmprestimoLivroModel {

    #emprestimoLivroId;
    #emprestimoId;
    #livroId;
    #emprestimoQuantidade;
    #dataEmprestimo;
    #dataDevolucao;
    #usuarioId;

    get emprestimoLivroId() {
        return this.#emprestimoLivroId;
    }

    set emprestimoLivroId(emprestimoLivroId){
        this.#emprestimoLivroId = emprestimoLivroId;
    }

    get emprestimoId() {
        return this.#emprestimoId;
    }
    set emprestimoId(emprestimoId){
        this.#emprestimoId = emprestimoId;
    }

    get livroId() {
        return this.#livroId;
    }
    set livroId(livroId){
        this.#livroId = livroId;
    }

    get emprestimoQuantidade() {
        return this.#emprestimoQuantidade;
    }
    set emprestimoQuantidade(emprestimoQuantidade){
        this.#emprestimoQuantidade = emprestimoQuantidade;
    }

    get dataEmprestimo() {
        return this.#dataEmprestimo;
    }

    set dataEmprestimo(dataEmprestimo){
        this.#dataEmprestimo = dataEmprestimo;
    }

    get dataDevolucao() {
        return this.#dataDevolucao;
    }

    set dataDevolucao(dataDevolucao){
        this.#dataDevolucao = dataDevolucao;
    }

    get usuarioId() {
        return this.#usuarioId;
    }

    set usuarioId(usuarioId){
        this.#usuarioId = usuarioId;
    }

    constructor() {

    }

    async gravar() {
        let sql = "insert into tb_emprestimolivros (emp_id, li_id, eli_quantidade, eli_dt_emprestimo, eli_dt_devolucao, usu_id) values (?, ?, ?, ?, ?, ?)";
        let valores = [this.#emprestimoId, this.#livroId, this.#emprestimoQuantidade, this.#dataEmprestimo, this.#dataDevolucao, this.#usuarioId];

        return await conexao.ExecutaComandoNonQuery(sql, valores);
    }

    async listar(termo, busca, ordenacao) {

        let sqlWhere = "";
        if(termo != undefined && termo != ""){
            if(busca == "1") {
                sqlWhere = ` where li.li_titulo like '%${termo}%'  `;
            }
            else if(busca == "2") {
                if(isNaN(termo) == false)
                    //sqlWhere = ` where el.usu_id = ${termo} `;
                    sqlWhere = ` where li.li_cod = ${termo} `;
            }
            else if(busca == "3") {
                if(isNaN(termo) == false)
                    sqlWhere = ` where e.emp_id = ${termo} `
            };
        }

        let sqlOrder = "";
        if(ordenacao == "1"){
            sqlOrder = " order by e.emp_id ";
        }
        //data
        else if(ordenacao == "2"){
            sqlOrder = " order by el.eli_dt_emprestimo ";
        }
        else if (ordenacao == "3"){
            sqlOrder = " order by el.usu_id ";
            //sqlOrder = " order by el.eli_dt_devolucao ";
        }

        let sql = `select e.emp_id, li.li_id, li.li_cod,
        li.li_titulo, el.eli_dt_emprestimo, el.eli_dt_devolucao, el.usu_id
        from tb_emprestimo e
        inner join tb_emprestimolivros el on e.emp_id = el.emp_id
        inner join tb_livro li on li.li_id = el.li_id

        ${sqlWhere}
        ${sqlOrder}`;

        var rows = await conexao.ExecutaComando(sql);

        var relatorio = [];

        for(var i = 0; i < rows.length; i++){
            var row = rows[i];

            if(row["eli_dt_emprestimo"] != null){
                let dia = String(row["eli_dt_emprestimo"].getDate()).padStart(2, '0');
                let mes = String(row["eli_dt_emprestimo"].getMonth() + 1).padStart(2, '0');
                let ano = String(row["eli_dt_emprestimo"].getFullYear());
                var dtEmp = dia+"/"+mes+"/"+ano;
            } else{ var dtEmp = "-";}
            if(row["eli_dt_devolucao"] != null){
                let dia = String(row["eli_dt_devolucao"].getDate()).padStart(2, '0');
                let mes = String(row["eli_dt_devolucao"].getMonth() + 1).padStart(2, '0');
                let ano = String(row["eli_dt_devolucao"].getFullYear());
                var dtDev = dia+"/"+mes+"/"+ano;
            }else{ var dtDev = "-";}

            if(row["usu_id"] != null){
                let usuario = await new UsuarioModel().buscarUsuario(row["usu_id"]);
                var data = {
                    nomeLivro: row["li_titulo"],
                    livroCodigo: row["li_cod"],
                    livroId: row["li_id"],
                    emprestimoId: row["emp_id"],
                    dataEmprestimo: dtEmp,
                    dataDevolucao: dtDev,
                    usuarioNome: usuario.usuarioNome
                }
            }
            else{
                var data = {
                    nomeLivro: row["li_titulo"],
                    livroCodigo: row["li_cod"],
                    livroId: row["li_id"],
                    emprestimoId: row["emp_id"],
                    dataEmprestimo: dtEmp,
                    dataDevolucao: dtDev,
                    usuarioNome: "-"
                }
            }           

            relatorio.push(data);
        }

        return relatorio;
    }
}

module.exports = EmprestimoLivroModel;