document.addEventListener('DOMContentLoaded', function() {

 
    var btnAddCarrinho = document.querySelectorAll('.btnAddCarrinho');
    for(var i = 0; i < btnAddCarrinho.length; i++){
        btnAddCarrinho[i].addEventListener('click', adicionarAoCarrinho);
    }


    //atualizar contador
    let listaCarrinho = localStorage.getItem("carrinho");
    if(listaCarrinho != null && listaCarrinho != ""){
        listaCarrinho = JSON.parse(listaCarrinho);
        document.getElementById("contadorCarrinho").innerText = listaCarrinho.length;
    }

    let modalCarrinho = document.getElementById("emprestimoModal");
    modalCarrinho.addEventListener("show.bs.modal", carregarCarrinho);

    var btnGravarPedido = document.getElementById("btnGravarPedido");
    btnGravarPedido.addEventListener("click", gravarPedido);
})

function gravarPedido() {
    let carrinho = localStorage.getItem('carrinho');

    if(carrinho != null && carrinho != ''){

        fetch('/gravar-pedido', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: carrinho
        })
        .then(r => {
            return r.json();
        })
        .then(function(r) {
            if(r.ok){
                alert("Pedido gravado com sucesso");
                //remove tudo do localStorage
                //localStorage.clear();
                //remove apenas uma chave com seu valor do local
                localStorage.removeItem('carrinho');
                carregarCarrinho();
            }
            else{
                alert(r.msg);
            }
        })
        .catch(function(e) {

        })
    }
    else{
        alert("Carrinho vazio!!!");
    }
}

function excluirItem(id) {

    if(confirm("Tem certeza que deseja excluir?")){
        let carrinho = localStorage.getItem('carrinho');
        if(carrinho != "" && carrinho != null) {
            let listaCarrinho = JSON.parse(carrinho);
    
            listaCarrinho = listaCarrinho.filter(livro => livro.id != id);
            document.getElementById("contadorCarrinho").innerText = listaCarrinho.length;
            localStorage.setItem("carrinho", JSON.stringify(listaCarrinho));
        }
    
        carregarCarrinho();
    }
}

function carregarCarrinho() {
    
    let carrinho  = localStorage.getItem('carrinho');
    if(carrinho != null && carrinho != "") {
        let listaCarrinho = JSON.parse(carrinho);

        let htmlCorpoModal = "";
        for(let i = 0; i< listaCarrinho.length; i++) {
            var obj = listaCarrinho[i];
            console.log("obj",obj);
            //<div> ${obj.autorNome} </div>

            htmlCorpoModal += `<tr>
                                    <td>
                                        <div class="itemCarrinho">
                                            <div>
                                                <img width='100' alt='Imagem livro' src='${obj.imagem}' />
                                            </div> 
                                            <div class='descricaoItem'>
                                                <div> ${obj.nome} </div>

                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class='divBotoesCarrinho'>
                                            <input id='inputQtde-${obj.id}' onchange='mudaInputValue(${obj.id})' style='width:50px;' disabled="true" class='form-control' value='${obj.quantidade}'/>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <button class='btn btn-danger excluirItem' onclick='excluirItem(${obj.id})' >Excluir</button>
                                        </div>
                                    </td>
                                </tr>`;
        }

        document.getElementById("corpoTabelaCarrinho").innerHTML = htmlCorpoModal;
    }
    else {
        document.getElementById("corpoModal").innerHTML = 'Carrinho vazio!';
    }
}

function adicionarAoCarrinho() {

    var livroId = this.dataset.livro;

    if(livroId != null && livroId != ""){

        fetch('/admin/livro/buscar', {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({id: livroId})
        })
        .then(r=> {
            return r.json();
        })
        .then(r=> {
            if(r.ok) {
                console.log(r.retorno);
                let listaCarrinho = [];
                let carrinho = localStorage.getItem("carrinho");
                if(carrinho != null && carrinho != "") {

                    //recupera
                    listaCarrinho = JSON.parse(carrinho);

                    //buscar livro igual;
                    let adiciona = true;
                    for(let i = 0; i<listaCarrinho.length; i++){
                        if(r.retorno.id == listaCarrinho[i].id) {
                            alert("Esse livro já está no carrinho!");
                            adiciona = false;
                        }
                    }

                    //adiciona apenas se nao tiver outro igual
                    if(adiciona == true) {
                        r.retorno.quantidade = 1;
                        listaCarrinho.push(r.retorno);
                        alert("Livro adicionado ao carrinho!");
                    }
                        
                    //atualiza o localstorage
                    localStorage.setItem("carrinho", JSON.stringify(listaCarrinho));
                }
                else {
                    //somente adiciona no localstorage
                    r.retorno.quantidade = 1;
                    listaCarrinho.push(r.retorno);
                    localStorage.setItem('carrinho', JSON.stringify(listaCarrinho));
                }

                document.getElementById("contadorCarrinho").innerText = listaCarrinho.length;
            }
            else {
                alert(r.msg);
            }
                
        })
        .catch(e => {
            console.log(e);
        })
    }
}