const PedidoItemModel = require("../models/pedidoItemModel");
const PedidoModel = require("../models/pedidoModel");
const LivroModel = require("../models/livroModel");

class VitrineController {

    async listarLivrosView(req, res) {
        let livro = new LivroModel();
        let listaLivros = await livro.listarLivros();

        res.render('vitrine/index', { livros: listaLivros, layout: 'vitrine/index' });
    }

    async gravarPedido(req, res){
        var ok = false;
        var msg = "";
        if(req.body != null && req.body != ""){
            if(req.body.length > 0) {
                let listaPedido = req.body;
                let pedido = new PedidoModel();
                let livro = new LivroModel();
                let lista = [];
                for(let i=0; i<listaPedido.length; i++)
                    lista.push({ id: listaPedido[i].id, nome: listaPedido[i].nome, qtd: listaPedido[i].quantidade});
                    
                var validacao = await livro.validarEmprestimo(lista);
                if(validacao == ""){
                    await pedido.gravar();
                    if(pedido.emprestimoId > 0){
                        for(let i = 0; i<listaPedido.length; i++){
                            let pedidoItem = new PedidoItemModel();
                            pedidoItem.emprestimoId = pedido.emprestimoId;
                            pedidoItem.livroId = listaPedido[i].id;
                            pedidoItem.emprestimoQuantidade = listaPedido[i].quantidade;

                            ok = await pedidoItem.gravar();
                        }
                    }
                    else{
                        msg = "Erro ao gerar pedido!";
                    }
                }
                else{
                    msg = validacao;
                }  
            }
            else{
                msg = "Carrinho vazio!";
            }
        }
        else{
            msg = "Parâmetros inválidos";
        }

        res.send({ok: ok, msg: msg});
    }
}

module.exports = VitrineController;