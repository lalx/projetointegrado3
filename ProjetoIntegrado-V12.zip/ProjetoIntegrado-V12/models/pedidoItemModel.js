const Database = require('../db/database');
const LivroModel = require('./livroModel');

const conexao = new Database();

class PedidoItemModel {

    #emprestimoLivroId;
    #emprestimoId;
    #livroId;
    #emprestimoQuantidade;

    get emprestimoLivroId() {
        return this.#emprestimoLivroId;
    }

    set emprestimoLivroId(emprestimoLivroId){
        this.#emprestimoLivroId = emprestimoLivroId;
    }

    get emprestimoId() {
        return this.#emprestimoId;
    }
    set emprestimoId(emprestimoId){
        this.#emprestimoId = emprestimoId;
    }

    get livroId() {
        return this.#livroId;
    }
    set livroId(livroId){
        this.#livroId = livroId;
    }

    get emprestimoQuantidade() {
        return this.#emprestimoQuantidade;
    }
    set emprestimoQuantidade(emprestimoQuantidade){
        this.#emprestimoQuantidade = emprestimoQuantidade;
    }

    constructor() {

    }

    async gravar() {
        let sql = "insert into tb_emprestimolivros (emp_id, li_id, eli_quantidade) values (?, ?, ?)";
        let valores = [this.#emprestimoId, this.#livroId, this.#emprestimoQuantidade];

        return await conexao.ExecutaComandoNonQuery(sql, valores);
    }
}

module.exports = PedidoItemModel;