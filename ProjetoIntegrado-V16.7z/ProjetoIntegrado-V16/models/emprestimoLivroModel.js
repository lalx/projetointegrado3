const Database = require('../db/database');

const conexao = new Database();

class EmprestimoLivroModel {

    #emprestimoLivroId;
    #emprestimoId;
    #livroId;
    #emprestimoQuantidade;

    get emprestimoLivroId() {
        return this.#emprestimoLivroId;
    }

    set emprestimoLivroId(emprestimoLivroId){
        this.#emprestimoLivroId = emprestimoLivroId;
    }

    get emprestimoId() {
        return this.#emprestimoId;
    }
    set emprestimoId(emprestimoId){
        this.#emprestimoId = emprestimoId;
    }

    get livroId() {
        return this.#livroId;
    }
    set livroId(livroId){
        this.#livroId = livroId;
    }

    get emprestimoQuantidade() {
        return this.#emprestimoQuantidade;
    }
    set emprestimoQuantidade(emprestimoQuantidade){
        this.#emprestimoQuantidade = emprestimoQuantidade;
    }

    constructor() {

    }

    async gravar() {
        let sql = "insert into tb_emprestimolivros (emp_id, li_id, eli_quantidade) values (?, ?, ?)";
        let valores = [this.#emprestimoId, this.#livroId, this.#emprestimoQuantidade];

        return await conexao.ExecutaComandoNonQuery(sql, valores);
    }

    async listar(termo, busca, ordenacao) {

        let sqlWhere = "";
        if(termo != undefined && termo != ""){
            if(busca == "1") {
                sqlWhere = ` where li.li_titulo like '%${termo}%'  `;
            }
            else if(busca == "2") {
                if(isNaN(termo) == false)
                    sqlWhere = ` where li.li_cod = ${termo} `;
                    //data
            }
            else if(busca == "3") {
                if(isNaN(termo) == false)
                    sqlWhere = ` where e.emp_id = ${termo} `
            };
        }

        let sqlOrder = "";
        if(ordenacao == "1"){
            sqlOrder = " order by e.emp_id ";
        }
        //data
        /*else if(ordenacao == "2"){
            sqlOrder = " order by valor ";
        }
        else if (ordenacao == "3"){
            sqlOrder = " order by el.eli_quantidade ";
        }*/

        let sql = `select e.emp_id, li.li_id, li.li_cod, 
        li.li_titulo
        from tb_emprestimo e 
        inner join tb_emprestimolivros el on e.emp_id = el.emp_id 
        inner join tb_livro li on li.li_id = el.li_id
        ${sqlWhere}
        ${sqlOrder}`;

        var rows = await conexao.ExecutaComando(sql);

        var relatorio = [];

        for(var i = 0; i < rows.length; i++){
            var row = rows[i];
            var data = {
                nomeLivro: row["li_titulo"],
                livroCodigo: row["li_cod"],
                livroId: row["li_id"],
                emprestimoId: row["emp_id"],
                //data emprestimo
                //data devolução
            }

            relatorio.push(data);
        }

        return relatorio;
    }
}

module.exports = EmprestimoLivroModel;