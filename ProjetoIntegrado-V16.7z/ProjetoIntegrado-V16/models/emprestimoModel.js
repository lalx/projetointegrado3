const Database = require("../db/database");

const conexao = new Database();

class EmprestimoModel {

    #emprestimoId;
    #dataEmprestimo;
    #dataDevolucao;

    get emprestimoId() {
        return this.#emprestimoId;
    }

    set emprestimoId(emprestimoId){
        this.#emprestimoId = emprestimoId;
    }

    get dataEmprestimo() {
        return this.#dataEmprestimo;
    }

    set dataEmprestimo(dataEmprestimo){
        this.#dataEmprestimo = dataEmprestimo;
    }

    get dataDevolucao() {
        return this.#dataDevolucao;
    }

    set dataDevolucao(dataDevolucao){
        this.#dataDevolucao = dataDevolucao;
    }

    constructor() {

    }

    async gravar() {
        //dataEmprestimo e dataDevolucao
        let sql = "insert into tb_emprestimo (emp_id) values (null)";
        var idGerado = await conexao.ExecutaComandoLastInserted(sql);
        this.#emprestimoId = idGerado;
    }
}

module.exports = EmprestimoModel;