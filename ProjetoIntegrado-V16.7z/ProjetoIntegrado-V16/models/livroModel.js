const Database = require('../db/database');
const fs = require('fs');

const conexao = new Database();
class LivroModel {

    #livroId;
    #livroCodigo;
    #livroTitulo;
    #livroQuantidade;
    #autorId;
    #autorNome;
    #editoraId;
    #editoraNome;
    #livroImagem;

    get livroId() { return this.#livroId; } set livroId(livroId) {this.#livroId = livroId;}
    get livroCodigo() { return this.#livroCodigo; } set livroCodigo(livroCodigo) {this.#livroCodigo = livroCodigo;}
    get livroTitulo() { return this.#livroTitulo; } set livroTitulo(livroTitulo) {this.#livroTitulo = livroTitulo;}
    get livroQuantidade() { return this.#livroQuantidade; } set livroQuantidade(livroQuantidade) {this.#livroQuantidade = livroQuantidade;}
    get autorId() { return this.#autorId; } set autorId(autorId) {this.#autorId = autorId;}
    get autorNome() { return this.#autorNome; } set autorNome(autorNome) {this.#autorNome = autorNome;}
    get editoraId() { return this.#editoraId; } set editoraId(editoraId) {this.#editoraId = editoraId;}
    
    get editoraNome() { return this.#editoraNome; } set editoraNome(editoraNome) {this.#editoraNome = editoraNome;}

    get livroImagem() {return this.#livroImagem ;} set livroImagem(livroImagem) {this.#livroImagem = livroImagem ;}

    constructor(livroId, livroCodigo, livroTitulo, livroQuantidade, autorId, editoraId, autorNome, editoraNome, livroImagem) {
        this.#livroId = livroId
        this.#livroCodigo = livroCodigo
        this.#livroTitulo = livroTitulo
        this.#livroQuantidade = livroQuantidade
        this.#autorId = autorId;
        this.#autorNome = autorNome;
        this.#editoraId = editoraId;
        this.#editoraNome = editoraNome;
        this.#livroImagem = livroImagem;
    }

    async excluir(codigo){
        let sql = "delete from tb_livro where li_id = ?"
        let valores = [codigo];

        var result = await conexao.ExecutaComandoNonQuery(sql, valores);

        return result;
    }

    async validarEmprestimo(lista){
        let validar = "";
        let sql = 'select * from tb_livro where li_id = ?';
        for(let i=0; i<lista.length; i++){
            let ids = [lista[i].id];
            let rows = await conexao.ExecutaComando(sql, ids);
            if(rows.length > 0){
                let row = rows[0];
                if(lista[i].qtd > row["li_qtde"]){
                    validar = "Quantidade do Item '"+row["li_titulo"]+ "' indisponível.";
                }
            }
        }
        if(validar == ""){
            let sqlUpdate = "update tb_livro set li_qtde = ? where li_id = ?";
            for(let i=0; i<lista.length; i++){
                let ids = [lista[i].id];
                let rows = await conexao.ExecutaComando(sql, ids);
                if(rows.length > 0){
                    let row = rows[0];
                    row["li_qtde"] -= lista[i].qtd;
                    let qtdes = [row["li_qtde"], row["li_id"]];
                    await conexao.ExecutaComandoNonQuery(sqlUpdate, qtdes) > 0;
                }
            }
        }
        return validar;
    }

    async gravar() {
        if(this.#livroId == 0){
            let sql = "insert into tb_livro (li_cod, li_titulo, li_qtde, aut_id, edit_id, li_img) values (?, ?, ?, ?, ?, ?)";

            let valores = [this.#livroCodigo, this.#livroTitulo, this.#livroQuantidade, this.#autorId, this.#editoraId, this.#livroImagem];

            return await conexao.ExecutaComandoNonQuery(sql, valores);
        }
        else{
            //alterar
            let sql = "update tb_livro set li_cod = ?, li_titulo =?, li_qtde= ?, aut_id = ?, edit_id = ?, li_img = ? where li_id = ?";

            let valores = [this.#livroCodigo, this.#livroTitulo, this.#livroQuantidade, this.#autorId, this.#editoraId, this.#livroImagem, this.#livroId];

            return await conexao.ExecutaComandoNonQuery(sql, valores) > 0;
        }
    }

    async buscarLivros(id){
        let sql = 'select * from tb_livro p inner join tb_editora m on p.edit_id = m.edit_id inner join tb_autor c on p.aut_id = c.aut_id where li_id = ?';
        let valores = [id];
        var rows = await conexao.ExecutaComando(sql, valores);

        let livro = null;

        if(rows.length > 0){
            var row = rows[0];

            let livImagem = row["li_img"];
            if(livImagem != null && livImagem != ""){
                //checar se existe
                if(fs.existsSync(global.RAIZ_PROJETO + "/public" + global.LIVRO_IMG_CAMINHO + livImagem) == false) {
                    livImagem = "sem-imagem.png";
                }
            }
            else {
                livImagem = "sem-imagem.png"
            }

            livImagem = global.LIVRO_IMG_CAMINHO + livImagem;
            livro = new LivroModel(row['li_id'], 
            row['li_cod'], row['li_titulo'], row['li_qtde'], 
            row['aut_id'], row['edit_id'], row['aut_nome'], row['edit_nome'], livImagem, row['li_img']);
        }

        return livro;
    }

    async listarLivros() {

        let sql = 'select * from tb_livro p inner join tb_autor c on p.aut_id = c.aut_id inner join tb_editora m on p.edit_id = m.edit_id';
        
        var rows = await conexao.ExecutaComando(sql);

        let listaRetorno = [];

        if(rows.length > 0){
            for(let i=0; i<rows.length; i++){
                var row = rows[i];

                let livImagem = row["li_img"];
                if(livImagem != null && livImagem != ""){
                    //checar se existe
                    if(fs.existsSync(global.RAIZ_PROJETO + "/public" + global.LIVRO_IMG_CAMINHO + livImagem) == false) {
                        livImagem = "sem-imagem.png";
                    }
                }
                else {
                    livImagem = "sem-imagem.png"
                }

                listaRetorno.push(new LivroModel(row['li_id'], 
                row['li_cod'], row['li_titulo'], row['li_qtde'], 
                row['aut_id'], row['edit_id'], row['aut_nome'], row['edit_nome'], livImagem, row['li_img']));
            }
        }

        return listaRetorno;
    }

    async validarAlteracao(titulo, autor, editora, id){
        let sql = "select * from tb_livro where (li_titulo = ? and aut_id = ? and edit_id = ?) and li_id != ?"
        let valores = [titulo, autor, editora, id];

        let rows = await conexao.ExecutaComando(sql, valores);
        if(rows.length > 0){
            return new LivroModel(rows[0]["li_id"], rows[0]["li_cod"], rows[0]["li_titulo"], rows[0]["li_qtde"], rows[0]["aut_id"],
            rows[0]["edit_id"], "", "", rows[0]["li_img"],);
        }
        return false;
    }

    async validarCadastro(titulo, autor, editora){
        let sql = "select * from tb_livro where (li_titulo = ? and aut_id = ? and edit_id = ?)"
        let valores = [titulo, autor, editora];

        let rows = await conexao.ExecutaComando(sql, valores);
        if(rows.length > 0){
            return new LivroModel(rows[0]["li_id"], rows[0]["li_cod"], rows[0]["li_titulo"], rows[0]["li_qtde"], rows[0]["aut_id"],
            rows[0]["edit_id"], "", "", rows[0]["li_img"],);
        }
        return false;
    }

}

module.exports = LivroModel;