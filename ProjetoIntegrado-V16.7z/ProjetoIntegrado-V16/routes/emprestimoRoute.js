const express = require('express');
const EmprestimoController = require('../controllers/emprestimoController');
const Autenticacao = require('../middlewares/autenticacao');

class EmprestimoRoute {

    #router;
    get router() {
        return this.#router;
    }
    set router(router) {
        this.#router = router
    }

    constructor() {
        this.#router = express.Router();

        let ctrl = new EmprestimoController();
        let auth = new Autenticacao();
        this.#router.get('/', auth.usuarioIsAdmin, ctrl.listaView);
        this.#router.post('/listar', auth.usuarioIsAdmin, ctrl.listarEmprestimos);        
    }
}

module.exports = EmprestimoRoute;