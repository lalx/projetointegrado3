const EditoraModel = require("../models/editoraModel");

class EditoraController {

    async listarView(req, res) {
        let editora = new EditoraModel();
        let lista = await editora.listarEditoras();
        res.render('editora/listar', {lista: lista});
    }
}

module.exports = EditoraController;