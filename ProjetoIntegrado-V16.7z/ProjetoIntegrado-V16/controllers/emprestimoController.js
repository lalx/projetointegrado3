const EmprestimoLivroModel = require("../models/emprestimoLivroModel")

class EmprestimoController {

    async listaView(req, res) {
        let emprestimoLivro = new EmprestimoLivroModel();
        let relatorio = await emprestimoLivro.listar();
        res.render('emprestimo/listar', {lista: relatorio});
    }

    async listarEmprestimos(req, res){
        let ok = false;
        let listaRetorno = [];
        if(req.body != undefined){
            let termo = req.body.termo;
            let busca = req.body.busca;
            let ordenacao = req.body.ordenacao;
            let emprestimo = new EmprestimoLivroModel();
            listaRetorno = await emprestimo.listar(termo, busca, ordenacao);
            ok = true;
        }

        res.send({ok: ok, listaRetorno: listaRetorno});
    }
}

module.exports = EmprestimoController;