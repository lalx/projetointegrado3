const AutorModel = require("../models/autorModel");

class AutorController {

    async listarView(req, res) {
        let cat = new AutorModel
        let lista = await cat.listarAutores();
        res.render('autor/listar', {lista: lista});
    }
}

module.exports = AutorController;