const express = require('express');
const EmprestimoController = require('../controllers/emprestimoController');

class EmprestimoRoute {

    #router;
    get router() {
        return this.#router;
    }
    set router(router) {
        this.#router = router
    }

    constructor() {
        this.#router = express.Router();

        let ctrl = new EmprestimoController();
        this.#router.get('/', ctrl.listaView);
        this.#router.post('/listar', ctrl.listarEmprestimos);        
    }
}

module.exports = EmprestimoRoute;