document.addEventListener("DOMContentLoaded", function() {

    var btnPesquisa = document.getElementById("btnPesquisa");

    /*document.getElementById("inputPesquisa").addEventListener("keyup", function() {
        var termo = document.getElementById("inputPesquisa").value;
        filtrarTabela(termo);
    })*/

    btnPesquisa.addEventListener("click", function() {
        var termo = document.getElementById("inputPesquisa").value;
        var busca = document.getElementById("selBusca").value;
        var ordenacao = document.querySelector("input[name='rdOrdenacao']:checked").value;
        filtrarTabela(termo, busca, ordenacao);
    })

    var btnExportar = document.getElementById("btnExportarExcel");

    btnExportar.addEventListener("click", function() {

        var wb = XLSX.utils.table_to_book(document.getElementById("tabelaEmprestimos"));
        /* Export to file (start a download) */
        XLSX.writeFile(wb, "relatorio-emprestimos.xlsx");

    })
})

function filtrarTabela(termo, busca, ordenacao) {


    fetch('/admin/emprestimos/listar', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(
            {termo: termo, busca: busca, ordenacao: ordenacao}
            )
    })
    .then(function(r) {
        return r.json();
    })
    .then(r=> {
        if(r.ok){
            if(r.listaRetorno.length > 0){
                let html = "";

                for(let i = 0; i < r.listaRetorno.length; i++){
                    var obj = r.listaRetorno[i];

                    html += ` <tr>
                                <td>${obj.emprestimoId}</td>
                                <td>${obj.livroCodigo}</td>
                                <td>${obj.nomeLivro}</td>
                                <td>${obj.dataEmprestimo}</td>
                                <td>${obj.dataDevolucao}</td>
                            </tr>`;
                }

                document.getElementById("rotuloQtdeEmprestimos").innerHTML = "<b>Quantidade de empréstimos: "+ r.listaRetorno.length +"</b>"
                document.getElementById("corpoTabelaEmprestimo").innerHTML = html;
            }
            else{
                alert("Nenhum empréstimo encontrado!");
            }
        }
    })
    .catch(e => {
        console.log(e);
    })
}