const express = require('express');
const VitrineController = require('../controllers/vitrineController');
const Autenticacao = require('../middlewares/autenticacao');

class VitrineRoute {

    #router;

    get router() {
        return this.#router;
    }
    set router(router) {
        this.#router = router
    }

    constructor() {

        this.#router = express.Router();

        let ctrl = new VitrineController();
        let auth = new Autenticacao();

        this.#router.get('/', auth.possuiAutenticacao, ctrl.listarLivrosView);
        this.#router.post('/gravar-emprestimo', auth.usuarioEstaLogado, ctrl.gravarEmprestimo);
    }
}

module.exports = VitrineRoute;