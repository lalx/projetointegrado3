const express = require('express');
const multer = require("multer");
const LivroController = require('../controllers/livroController');
const Autenticacao = require('../middlewares/autenticacao');

class LivroRoute {

    #router;
    get router() {
        return this.#router;
    }
    set router(router) {
        this.#router = router
    }

    constructor() {
        this.#router = express.Router();

        let storage = multer.diskStorage({
            destination: function(req, res, cb) {
                cb(null, 'public/img/Livros');
            },
            filename: function(req, file, cb) {
                var ext = file.originalname.split(".")[1];
                cb(null, Date.now().toString() + "." + ext);
            }
        })

        let upload = multer({storage});
        let auth = new Autenticacao();
        let ctrl = new LivroController();
        this.#router.get('/', auth.usuarioIsAdmin, ctrl.listarView);
        this.#router.get('/cadastro', auth.usuarioIsAdmin, ctrl.cadastroView);
        this.#router.post("/cadastro", auth.usuarioIsAdmin, upload.single("inputImagem"), ctrl.cadastrarLivro);
        this.#router.post("/excluir", auth.usuarioIsAdmin, ctrl.excluirLivro);
        this.#router.get("/alterar/:id", auth.usuarioIsAdmin, ctrl.alterarView);
        this.#router.post("/alterar", auth.usuarioIsAdmin, upload.single("inputImagem"),ctrl.alterarLivro);
        this.#router.post("/buscar", ctrl.buscalivro);
    }
}

module.exports = LivroRoute;