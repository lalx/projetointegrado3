const express = require('express');
const EditoraController = require('../controllers/editoraController');
const Autenticacao = require('../middlewares/autenticacao');

class EditoraRoute {

    #router;
    get router() {
        return this.#router;
    }
    set router(router) {
        this.#router = router
    }

    constructor() {
        this.#router = express.Router();

        let ctrl = new EditoraController();
        let auth = new Autenticacao();
        this.#router.get('/', auth.usuarioIsAdmin, ctrl.listarView);
    }
}

module.exports = EditoraRoute;