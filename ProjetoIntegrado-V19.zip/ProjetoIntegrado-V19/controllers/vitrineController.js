const EmprestimoLivroModel = require("../models/emprestimoLivroModel");
const EmprestimoModel = require("../models/EmprestimoModel");
const LivroModel = require("../models/livroModel");

class VitrineController {

    async listarLivrosView(req, res) {
        let livro = new LivroModel();
        let listaLivros = await livro.listarLivros();

        res.render('vitrine/index', { livros: listaLivros, layout: 'vitrine/index' });
    }

    async gravarEmprestimo(req, res){
        var ok = false;
        var msg = "";
        if(req.body != null && req.body != ""){
            if(req.body.length > 0) {
                let listaEmprestimo = req.body;
                let emprestimo = new EmprestimoModel();
                let livro = new LivroModel();
                let lista = [];
                for(let i=0; i<listaEmprestimo.length; i++)
                    lista.push({ id: listaEmprestimo[i].id, nome: listaEmprestimo[i].nome, qtd: listaEmprestimo[i].quantidade});
                    
                var validacao = await livro.validarEmprestimo(lista);
                if(validacao == ""){
                    await emprestimo.gravar();
                    
                    let dataHoje = new Date();

                    let dia = String(dataHoje.getDate()).padStart(2, '0');
                    let mes = String(dataHoje.getMonth() +1).padStart(2, '0');
                    let ano = dataHoje.getFullYear();
                    var dataEmp = ano+"-"+mes+"-"+dia;

                    let diaD = String(dataHoje.getDate()).padStart(2, '0');
                    let mesD = String(dataHoje.getMonth() +1).padStart(2, '0');
                    let anoD = dataHoje.getFullYear();
                    if((dataHoje.getMonth() +2) >12){
                        mesD = 1; anoD += 1 }
                    else{ mesD = dataHoje.getMonth()+2 }
                    var dataDev = anoD+"-"+mesD+"-"+diaD;
                    
                    if(emprestimo.emprestimoId > 0){
                        for(let i = 0; i<listaEmprestimo.length; i++){
                            let emprestimoLivro = new EmprestimoLivroModel();
                            emprestimoLivro.emprestimoId = emprestimo.emprestimoId;
                            emprestimoLivro.livroId = listaEmprestimo[i].id;
                            emprestimoLivro.emprestimoQuantidade = listaEmprestimo[i].quantidade;
                            emprestimoLivro.dataEmprestimo = dataEmp;
                            emprestimoLivro.dataDevolucao = dataDev;
                            emprestimoLivro.usuarioId = req.cookies.usuarioLogado;

                            ok = await emprestimoLivro.gravar();
                        }
                    }
                    else{
                        msg = "Erro ao gerar emprestimo!";
                    }
                }
                else{
                    msg = validacao;
                }  
            }
            else{
                msg = "Carrinho vazio!";
            }
        }
        else{
            msg = "Parâmetros inválidos";
        }

        res.send({ok: ok, msg: msg});
    }
}

module.exports = VitrineController;