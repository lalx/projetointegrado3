const PedidoItemModel = require("../models/pedidoItemModel");
const PedidoModel = require("../models/pedidoModel");
const ProdutoModel = require("../models/produtoModel");

class VitrineController {

    async listarProdutosView(req, res) {
        let produto = new ProdutoModel();
        let listaProdutos = await produto.listarProdutos();

        res.render('vitrine/index', { produtos: listaProdutos, layout: 'vitrine/index' });
    }

    async gravarPedido(req, res){
        var ok = false;
        var msg = "";
        if(req.body != null && req.body != ""){
            if(req.body.length > 0) {
                let listaPedido = req.body;
                let pedido = new PedidoModel();
                let produto = new ProdutoModel();
                let lista = [];
                for(let i=0; i<listaPedido.length; i++)
                    lista.push({ id: listaPedido[i].id, nome: listaPedido[i].nome, qtd: listaPedido[i].quantidade});
                    
                var validacao = await produto.validarPedido(lista);
                if(validacao == ""){
                    await pedido.gravar();
                    if(pedido.pedidoId > 0){
                        for(let i = 0; i<listaPedido.length; i++){
                            let pedidoItem = new PedidoItemModel();
                            pedidoItem.pedidoId = pedido.pedidoId;
                            pedidoItem.produtoId = listaPedido[i].id;
                            pedidoItem.pedidoQuantidade = listaPedido[i].quantidade;

                            ok = await pedidoItem.gravar();
                        }
                    }
                    else{
                        msg = "Erro ao gerar pedido!";
                    }
                }
                else{
                    validacao.join("\n");
                    msg = validacao;
                }
            }
            else{
                msg = "Carrinho vazio!";
            }
        }
        else{
            msg = "Parâmetros inválidos";
        }

        res.send({ok: ok, msg: msg});
    }
}

module.exports = VitrineController;