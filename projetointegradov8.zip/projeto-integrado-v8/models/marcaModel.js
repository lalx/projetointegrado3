const Database = require('../db/database');

const conexao = new Database();

class AutorModel {

    #autorId;
    #autorNome;

    get autorId() { return this.#autorId; } set autorId(autorId) {this.#autorId = autorId;}
    get autorNome() { return this.#autorNome; } set autorNome(autorNome) {this.#autorNome = autorNome;}

    constructor(autorId, autorNome) {
        this.#autorId = autorId;
        this.#autorNome = autorNome;
    }


    async listarAutores() {

        let sql = 'select * from tb_autor';
        
        var rows = await conexao.ExecutaComando(sql);

        let listaRetorno = [];

        if(rows.length > 0){
            for(let i=0; i<rows.length; i++){
                var row = rows[i];
                listaRetorno.push(new AutorModel
                    (row['aut_id'], row['aut_nome']));
            }
        }

        return listaRetorno;
    }

}

module.exports = AutorModel;