const Database = require("../db/database");

const conexao = new Database();

class PedidoModel {

    #pedidoId;

    get pedidoId() {
        return this.#pedidoId;
    }

    set pedidoId(pedidoId){
        this.#pedidoId = pedidoId;
    }

    constructor() {

    }

    async gravar() {
        let sql = "insert into tb_pedido (ped_id) values (null)";
        var idGerado = await conexao.ExecutaComandoLastInserted(sql);
        this.#pedidoId = idGerado;
    }
}

module.exports = PedidoModel;