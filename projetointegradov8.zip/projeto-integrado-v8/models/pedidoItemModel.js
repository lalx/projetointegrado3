const Database = require('../db/database');
const ProdutoModel = require('./produtoModel');

const conexao = new Database();

class PedidoItemModel {

    #pedidoItemId;
    #pedidoId;
    #produtoId;
    #pedidoQuantidade;

    get pedidoItemId() {
        return this.#pedidoItemId;
    }

    set pedidoItemId(pedidoItemId){
        this.#pedidoItemId = pedidoItemId;
    }

    get pedidoId() {
        return this.#pedidoId;
    }
    set pedidoId(pedidoId){
        this.#pedidoId = pedidoId;
    }

    get produtoId() {
        return this.#produtoId;
    }
    set produtoId(produtoId){
        this.#produtoId = produtoId;
    }

    get pedidoQuantidade() {
        return this.#pedidoQuantidade;
    }
    set pedidoQuantidade(pedidoQuantidade){
        this.#pedidoQuantidade = pedidoQuantidade;
    }

    constructor() {

    }

    async gravar() {
        let sql = "insert into tb_pedidoitens (ped_id, prd_id, pit_quantidade) values (?, ?, ?)";
        let valores = [this.#pedidoId, this.#produtoId, this.#pedidoQuantidade];

        return await conexao.ExecutaComandoNonQuery(sql, valores);
    }
}

module.exports = PedidoItemModel;