document.addEventListener("DOMContentLoaded", function(){

    var btnGravar = document.getElementById("btnAlterar");

    btnGravar.addEventListener("click", alterarLivro);

    
    var inputImagem = document.getElementById("inputImagem");

    inputImagem.addEventListener("change", exibirImagem);
})

function exibirImagem() {
    
    var inputValue = document.getElementById("inputImagem").files[0];

    if(inputValue.name.includes(".jpg") || inputValue.name.includes(".png")) {
        var imgInput = document.getElementById("imgInput");
        imgInput.src = URL.createObjectURL(inputValue);
        imgInput.style["display"] = "block";
    }
    else{
        alert("Formato inválido (Apenas .jpg e .png)");
    }

}

function alterarLivro() {
    
    var inputId = document.getElementById("inputId");
    var inputCodigo = document.getElementById("inputCodigo");
    var inputNome = document.getElementById("inputNome");
    var inputQtde = document.getElementById("inputQtde");
    var selAutor = document.getElementById("selAutor");
    var selEditora = document.getElementById("selEditora");
    var inputFile = document.getElementById("inputImagem")

    //if de validação básica
    if(inputCodigo.value != "" && inputNome.value != "" && inputQtde.value != "" && inputQtde.value != '0' && selAutor.value != '0' && selEditora.value != '0' && inputFile.files.length > 0){

        var inputValue = inputFile.files[0];
        if(inputValue.name.includes(".jpg") ||inputValue.name.includes(".png")) {

            var formData = new FormData();

            formData.append("id", inputId.value);
            formData.append("codigo", inputCodigo.value);
            formData.append("nome", inputNome.value);
            formData.append("quantidade", inputQtde.value);         
            formData.append("autor", selAutor.value);
            formData.append("editora", selEditora.value);
            formData.append("inputImagem", inputValue);

            fetch('/admin/livro/alterar', {
                method: "POST",
                body: formData
            })
            .then(r => {
                return r.json();
            })
            .then(r=> {
                if(r.ok) {
                    alert("Livro alterado!");
                }
                else{
                    alert("Erro ao alterar livro");
                }
            })
            .catch(e => {
                console.log(e);
            })
        }
        else {
            alert("Imagem com formato inválido!");
            return;
        }
    }
    else{
        alert("Preencha todos os campos corretamente!");
        return;
    }
}