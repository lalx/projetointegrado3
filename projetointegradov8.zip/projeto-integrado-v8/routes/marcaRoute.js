const express = require('express');
const AutorController = require('../controllers/autorController');

class AutorRoute {

    #router;
    get router() {
        return this.#router;
    }
    set router(router) {
        this.#router = router
    }

    constructor() {
        this.#router = express.Router();

        let ctrl = new AutorController();
        this.#router.get('/', ctrl.listarView);
    }
}

module.exports = AutorRoute;