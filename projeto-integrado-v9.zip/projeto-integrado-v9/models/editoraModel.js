const Database = require('../db/database');

const conexao = new Database();
class EditoraModel {

    #editoraId;
    #editoraNome;

    get editoraId() { return this.#editoraId; } set editoraId(editoraId) {this.#editoraId = editoraId;}
    get editoraNome() { return this.#editoraNome; } set editoraNome(editoraNome) {this.#editoraNome = editoraNome;}

    constructor(editoraId, editoraNome) {
        this.#editoraId = editoraId
        this.#editoraNome = editoraNome
    }


    async listarEditoras() {

        let sql = 'select * from tb_editora';
        
        var rows = await conexao.ExecutaComando(sql);

        let listaRetorno = [];

        if(rows.length > 0){
            for(let i=0; i<rows.length; i++){
                var row = rows[i];
                listaRetorno.push(new EditoraModel(row['edit_id'], row['edit_nome']));
            }
        }

        return listaRetorno;
    }

}

module.exports = EditoraModel;