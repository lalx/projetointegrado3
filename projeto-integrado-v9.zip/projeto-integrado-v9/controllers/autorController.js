const AutorModel = require("../models/autorModel");

class AutorController {

    async listarView(req, res) {
        let autor = new AutorModel();
        let lista = await autor.listarAutores();
        res.render('autor/listar', {lista: lista});
    }
}

module.exports = AutorController;