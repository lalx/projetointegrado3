const EditoraModel = require("../models/editoraModel");

class EditoraController {

    async listarView(req, res) {
        let edit = new EditoraModel();
        let lista = await edit.listarEditoras();
        res.render('editora/listar', {lista: lista});
    }
}

module.exports = EditoraController;