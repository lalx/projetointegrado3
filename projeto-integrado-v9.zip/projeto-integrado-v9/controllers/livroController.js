const AutorModel = require("../models/autorModel");
const EditoraModel = require("../models/editoraModel");
const LivroModel = require("../models/livroModel");
const fs = require('fs');

class LivroController {

    async listarView(req, res) {
        let liv = new LivroModel();
        let lista = await liv.listarLivros();
        res.render('livro/listar', {lista: lista});
    }

    async buscaLivro(req, res) {
        var ok = true;
        var msg = ""
        var retorno = null;
        if(req.body.id != null && req.body.id != ""){
            let liv = new LivroModel();
            liv = await liv.buscarLivro(req.body.id);

            retorno = {
                nome: liv.livroNome,
                id: liv.livroId,
                autorNome: liv.autorNome,
                editoraNome: liv.editoraNome,
                imagem: liv.livroImagem
            };
        }
        else {
            ok = false;
            msg = "Parâmetro inválido!";
        }

        res.send({ ok: ok, msg: msg, retorno: retorno })
    }

    async excluirLivro(req, res){
        var ok = true;
        if(req.body.codigo != "") {
            let livro = new LivroModel();
            ok = await livro.excluir(req.body.codigo);
        }
        else{
            ok = false;
        }

        res.send({ok: ok});
    }
    async cadastrarLivro(req, res){
        var ok = true;
        if(req.body.codigo != "" && req.body.nome != "" && req.body.quantidade != "" && req.body.quantidade  != '0' && req.body.autor != '0' && req.body.editora  != '0' && req.file != null && (req.file.filename.includes(".jpg") || req.file.filename.includes(".png")) ) {
            
            let livro = new LivroModel(0, req.body.codigo, req.body.nome, req.body.quantidade, req.body.autor, req.body.editora, "", "", req.file.filename);

            ok = await livro.gravar();
        }
        else{
            ok = false;
        }

        res.send({ ok: ok })
    }

    async alterarView(req, res){
        let livro = new LivroModel();
        let autor = new AutorModel();
        let editora = new EditoraModel();
       
        if(req.params.id != undefined && req.params.id != ""){
            livro = await livro.buscarLivro(req.params.id);
        }

        let listaAutor = await autor.listarAutores();
        let listaEditora = await editora.listarEditoras();
        res.render("livro/alterar", {livroAlter: livro, listaAutores: listaAutor, listaEditoras: listaEditora});
    }

    async alterarLivro(req, res) {
        var ok = true;
        if(req.body.codigo != "" && req.body.nome != "" && req.body.quantidade != "" && req.body.quantidade  != '0' && req.body.autor != '0' && req.body.editora  != '0' && req.file != null && (req.file.filename.includes(".jpg") || req.file.filename.includes(".png"))) {

            let livro = new LivroModel(req.body.id, req.body.codigo, req.body.nome, req.body.quantidade, req.body.autor, req.body.editora, "", "", req.file.filename);
            
            let livroOld = await livro.buscarLivro(req.body.id);

            if(livroOld.livroImagem != null && livroOld.livroImagem != "") {

                if(fs.existsSync(global.RAIZ_PROJETO + "/public" + global.LIVRO_IMG_CAMINHO + livroOld.livroImagem)){
                    fs.unlinkSync(global.RAIZ_PROJETO + "/public" + global.LIVRO_IMG_CAMINHO + livroOld.livroImagem)   
                }     
            }
            
            ok = await livro.gravar();
        }
        else{
            ok = false;
        }

        res.send({ ok: ok })
    }

    async cadastroView(req, res) {

        let listaAutores = [];
        let listaEditoras = [];

        let autor = new AutorModel();
        listaAutores = await autor.listarAutores();

        let editora = new EditoraModel();
        listaEditoras = await editora.listarEditoras();

        res.render('livro/cadastro', { listaAutores: listaAutores, listaEditoras: listaEditoras });
    }
}

module.exports = LivroController;