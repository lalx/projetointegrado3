document.addEventListener("DOMContentLoaded", function(){

    var btnGravar = document.getElementById("btnGravar");

    btnGravar.addEventListener("click", gravarProduto);

    var inputImagem = document.getElementById("inputImagem");

    inputImagem.addEventListener("change", exibirImagem);
})

function exibirImagem() {
    
    var inputValue = document.getElementById("inputImagem").files[0];

    if(inputValue.name.includes(".jpg") || inputValue.name.includes(".png")) {
        var imgInput = document.getElementById("imgInput");
        imgInput.src = URL.createObjectURL(inputValue);
        imgInput.style["display"] = "block";
    }
    else{
        alert("Formato inválido (Apenas .jpg e .png)");
    }

}

function gravarProduto() {

    var inputCodigo = document.getElementById("inputCodigo");
    var inputTitulo = document.getElementById("inputTitulo");
    var inputQtde = document.getElementById("inputQtde");
    var selEditora = document.getElementById("selEditora");
    var selAutor = document.getElementById("selAutor");

    var inputImagem = document.getElementById("inputImagem");

    //if de validação básica
    if(inputCodigo.value != "" && inputTitulo.value != "" && inputQtde.value != "" && inputQtde.value != '0' && selEditora.value != '0' && selAutor.value != '0' && inputImagem.files != null && inputImagem.files.length > 0) {


        var inputValue = inputImagem.files[0];
        if(inputValue.name.includes(".jpg") || inputValue.name.includes(".png")) {
            
            /*var data = {
                codigo: inputCodigo.value,
                nome: inputTitulo.value,
                quantidade: inputQtde.value,
                Autor: selAutor.value
                Editora: selEditora.value,
            }*/

            //para enviar arquivos, utilize FormData

            var formData = new FormData();
            formData.append("codigo", inputCodigo.value);
            formData.append("nome", inputTitulo.value);
            formData.append("quantidade", inputQtde.value); 
            formData.append("autor", selAutor.value);        
            formData.append("editora", selEditora.value);
            formData.append("inputImagem", inputValue);

            fetch('/admin/livro/cadastro', {
                method: "POST",
                body: formData
            })
            .then(r => {
                return r.json();
            })
            .then(r=> {
                if(r.ok) {
                    alert("Livro cadastrado!");
                }
                else{
                    alert("Erro ao cadastrar livro");
                }
            })
            .catch(e => {
                console.log(e);
            })
        }
        else{
            alert("Formato de arquivo inválido!")
        }
    }
    else{
        alert("Preencha todos os campos corretamente!");
        return;
    }
}