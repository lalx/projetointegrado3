const AutorModel = require("../models/autorModel");
const EditoraModel = require("../models/editoraModel");
const LivroModel = require("../models/livroModel");
const fs = require('fs');

class LivroController {

    async listarView(req, res) {
        let liv = new LivroModel();
        let lista = await liv.listarLivros();
        res.render('livro/listar', {lista: lista});
    }

    async buscalivro(req, res) {
        var ok = true;
        var msg = ""
        var retorno = null;
        if(req.body.id != null && req.body.id != ""){
            let liv = new LivroModel();
            liv = await liv.buscarLivros(req.body.id);

            retorno = {
                nome: liv.livroTitulo,
                id: liv.livroId,
                editoraNome: liv.editoraNome,
                autorNome: liv.autorNome,
                imagem: liv.livroImagem
            };
        }
        else {
            ok = false;
            msg = "Parâmetro inválido!";
        }

        res.send({ ok: ok, msg: msg, retorno: retorno })
    }

    async excluirLivro(req, res){
        var ok = true;
        if(req.body.codigo != "") {
            let livro = new LivroModel();
            ok = await livro.excluir(req.body.codigo);
        }
        else{
            ok = false;
        }

        res.send({ok: ok});
    }
    async cadastrarLivro(req, res){
        var ok = true;
        let livroExiste = new LivroModel();
        let existe = await livroExiste.validarCadastro(req.body.nome, req.body.autor, req.body.editora);

        if(req.body.codigo != "" && req.body.nome != "" && req.body.quantidade != "" && req.body.quantidade  != '0' && req.body.autor  != '0' && req.body.editora != '0' && req.file != null && (req.file.filename.includes(".jpg") || req.file.filename.includes(".png")) && existe == false) {
            if(req.body.nome != existe.livroTitulo && req.body.autor != existe.autorId && req.body.editora != existe.editoraId){
                let livro = new LivroModel(0, req.body.codigo, req.body.nome, req.body.quantidade, req.body.autor, req.body.editora, "", "", req.file.filename);
                ok = await livro.gravar();
            }
        }
        else{
            ok = false;
        }

        res.send({ ok: ok })
    }

    async alterarView(req, res){
        let livro = new LivroModel();
        let editora = new EditoraModel();
        
        let autor = new AutorModel();
        if(req.params.id != undefined && req.params.id != ""){
            livro = await livro.buscarLivros(req.params.id);
        }

        let listaEditoras = await editora.listarEditoras();
        let listaAutores = await autor.listarAutores();
        res.render("livro/alterar", {livroAlter: livro, listaEditoras: listaEditoras, listaAutores: listaAutores});
    }

    async alterarLivro(req, res) {
        var ok = true;
        let livroExiste = new LivroModel();
        let existe = await livroExiste.validarAlteracao(req.body.nome, req.body.autor, req.body.editora, req.body.id);

        if(req.body.codigo != "" && req.body.nome != "" && req.body.quantidade != "" && req.body.quantidade  != '0' && req.body.editora != '0' && req.body.autor  != '0' && existe == false) {
            if(req.file != null && (req.file.filename.includes(".jpg") || req.file.filename.includes(".png"))){
                if(req.body.nome != existe.livroTitulo && req.body.autor != existe.autorId && req.body.editora != existe.editoraId){
                    let livro = new LivroModel(req.body.id, req.body.codigo, req.body.nome, req.body.quantidade, req.body.autor, req.body.editora, "", "", req.file.filename);
                    
                    let livroOld = await livro.buscarLivros(req.body.id);

                    if(livroOld.livroImagem != null && livroOld.livroImagem != "") {

                        if(fs.existsSync(global.RAIZ_PROJETO + "/public" + global.LIVRO_IMG_CAMINHO + livroOld.livroImagem)){
                            fs.unlinkSync(global.RAIZ_PROJETO + "/public" + global.LIVRO_IMG_CAMINHO + livroOld.livroImagem)   
                        }     
                    }
                    
                    ok = await livro.gravar();
                }
            }else if(req.file == null){
                if(req.body.nome != existe.livroTitulo && req.body.autor != existe.autorId && req.body.editora != existe.editoraId){
                    let livro = new LivroModel(req.body.id, req.body.codigo, req.body.nome, req.body.quantidade, req.body.autor, req.body.editora, "", "", "");
                    let livroOld = await livro.buscarLivros(req.body.id);

                    let livroOldName = livroOld.livroImagem.split('/');
                    livroOldName = livroOldName[3];
                    let livroAtt = new LivroModel(req.body.id, req.body.codigo, req.body.nome, req.body.quantidade, req.body.autor, req.body.editora, "", "", livroOldName);                    
                    
                    ok = await livroAtt.gravar();
                }
            }
        }
        else{
            ok = false;
        }

        res.send({ ok: ok })
    }

    async cadastroView(req, res) {

        let listaEditoras = [];
        let listaAutores = [];

        let editora = new EditoraModel();
        listaEditoras = await editora.listarEditoras();

        let autor = new AutorModel();
        listaAutores = await autor.listarAutores();

        res.render('livro/cadastro', { listaEditoras: listaEditoras, listaAutores: listaAutores });
    }
}

module.exports = LivroController;